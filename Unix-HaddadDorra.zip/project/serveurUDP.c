#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define NMAX 100

void error(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <serveur_port>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // Récupérer le numéro de port depuis les arguments
    const int serveur_port = atoi(argv[1]);

    // Créer une socket UDP
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0)
        error("Erreur lors de la création de la socket");

    // Préparer l'adresse du serveur
    struct sockaddr_in serveur_addr, client_addr;
    socklen_t client_addr_len = sizeof(client_addr);

    serveur_addr.sin_family = AF_INET;
    serveur_addr.sin_port = htons(serveur_port);
    serveur_addr.sin_addr.s_addr = INADDR_ANY;

    // Lier la socket à l'adresse du serveur
    if (bind(sockfd, (struct sockaddr*)&serveur_addr, sizeof(serveur_addr)) < 0)
        error("Erreur lors de la liaison de la socket");

    // Attendre la réception d'un nombre n du client
    int n;
    if (recvfrom(sockfd, &n, sizeof(n), 0, (struct sockaddr*)&client_addr, &client_addr_len) < 0)
        error("Erreur lors de la réception du nombre du client");

    // Générer n nombres aléatoires
    int *nombre_aleatoire = malloc(n * sizeof(int));
    for (int i = 0; i < n; ++i) {
        nombre_aleatoire[i] = rand() % NMAX + 1;
    }

    // Envoyer la liste de nombres séparés par '|' au client
    if (sendto(sockfd, nombre_aleatoire, n * sizeof(int), 0, (struct sockaddr*)&client_addr, client_addr_len) < 0)
        error("Erreur lors de l'envoi des nombres aléatoires au client");

    // Libérer la mémoire
    free(nombre_aleatoire);

    // Fermer la socket
    close(sockfd);

    return 0;
}
