#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define BUFFER_SIZE  8192
// ANSI escape codes for text color
#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_RESET   "\x1b[0m"
#define NSIG 64
char name[BUFFER_SIZE];

void error(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}
void sendNumber(int sockfd, int number) {
    if (send(sockfd, &number, sizeof(number), 0) < 0) {
        perror("Error sending client number");
        exit(EXIT_FAILURE);
    }
}

long receiveResult(int sockfd) {
    long result;
    ssize_t bytesRead = recv(sockfd, &result, sizeof(result), 0);

    if (bytesRead <= 0) {
        perror("Error receiving factorial result");
        exit(EXIT_FAILURE);
    }

    return result;
}
void sendString(int sockfd, const char *str) {
    // Envoyer la longueur de la chaîne
    size_t length = strlen(str) + 1; // +1 pour inclure le caractère nul
    if (send(sockfd, &length, sizeof(length), 0) < 0)
        error("Erreur lors de l'envoi de la longueur de la chaîne");

    // Envoyer la chaîne de caractères
    if (send(sockfd, str, length, 0) < 0)
        error("Erreur lors de l'envoi de la chaîne");
}
void receiveString(int sockfd, char *buffer, size_t bufferSize) {
    size_t length;
    recv(sockfd, &length, sizeof(length), 0);  // recevoir la longueur de la chaîne
    if (length > bufferSize) {
        fprintf(stderr, "La taille du buffer n'est pas suffisante.\n");
        exit(EXIT_FAILURE);
    }
    
    ssize_t totalBytesReceived = 0;
    while (totalBytesReceived < length) {
        ssize_t bytesRead = recv(sockfd, buffer + totalBytesReceived, length - totalBytesReceived, 0);
        if (bytesRead <= 0) {
            fprintf(stderr, "Erreur lors de la réception de la chaîne.\n");
            exit(EXIT_FAILURE);
        }
        totalBytesReceived += bytesRead;
    }
    
    // Assurez-vous que la chaîne est terminée par un caractère nul
    buffer[length] = '\0';
}
/*void authenticateUser(int sockfd) {
    char username[BUFFER_SIZE];
    char password[BUFFER_SIZE];


    // Receive username and password from the user
    printf("Nom d'utilisateur : ");
    scanf("%s", username);
    sendString(sockfd, username);

    printf("Mot de passe : ");
    scanf("%s", password);
    sendString(sockfd, password);

    // Receive authentication result
    int authResult;
    if (read(sockfd, &authResult, sizeof(authResult)) < 0)
        error("Erreur lors de la lecture du résultat de l'authentification");

    if (authResult == 0) {
        fprintf(stderr, "Authentification échoué. Exiting.\n");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("Authentification avec succés\n Bonjour %s",username);
    strcpy(name, username);
}*/
void authenticateUser(int sockfd) {
    char username[BUFFER_SIZE];
    char password[BUFFER_SIZE];

    // Receive username and password from the user
    printf("%s---------------------- Authentification ----------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);

    // Get the username
    printf("%sNom d'utilisateur : %s", ANSI_COLOR_GREEN, ANSI_COLOR_RESET);
    scanf("%s", username);
    sendString(sockfd, username);

    // Get the password
    printf("%sMot de passe : %s", ANSI_COLOR_GREEN, ANSI_COLOR_RESET);
    scanf("%s", password);
    sendString(sockfd, password);

    // Receive authentication result
    int authResult;
    if (read(sockfd, &authResult, sizeof(authResult)) < 0)
        error("Erreur lors de la lecture du résultat de l'authentification");

    if (authResult == 0) {
        fprintf(stderr, "%s❌ Authentification échouée. Exiting. ❌%s\n", ANSI_COLOR_RED, ANSI_COLOR_RESET);
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("%s✅ Authentification réussie ✅\n", ANSI_COLOR_GREEN);
    printf("Bonjour %s%s%s\n", ANSI_COLOR_YELLOW, username, ANSI_COLOR_RESET);

    // End of authentication frame
    printf("%s--------------------------------------------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);

    strcpy(name, username);
}



void receiveFileContent(int serverSocket, const char *filename) {
    FILE *file = fopen(filename, "a");  // Utiliser "a" au lieu de "w"
    if (!file)
        error("Erreur lors de la création/ouverture du fichier local");

    // Recevoir la taille du fichier
    long fileSize;
    if (recv(serverSocket, &fileSize, sizeof(fileSize), 0) < 0)
        error("Erreur lors de la réception de la taille du fichier");

    char buffer[BUFFER_SIZE];
    size_t totalBytesReceived = 0;

    while (totalBytesReceived < fileSize) {
        ssize_t bytesRead = recv(serverSocket, buffer, sizeof(buffer), 0);
        if (bytesRead <= 0) {
            fprintf(stderr, "Erreur lors de la réception du contenu du fichier.\n");
            exit(EXIT_FAILURE);
        }

        fwrite(buffer, 1, bytesRead, stdout);
        totalBytesReceived += bytesRead;
    }

    fclose(file);
}

void sendSignalToServer(int clientSocket) {
    int signalNumber;

    printf("Entrer le numéro du signal que vous allez envoyer: ");
    scanf("%d", &signalNumber);

    // Check if the signal number is within the valid range
    if (signalNumber < 1 || signalNumber > NSIG) {
        fprintf(stderr, "Numéro du signal ivalide ❌. Veuillez saisir un numéro entre 1 et %d.\n", NSIG);
        return;
    }

    if (write(clientSocket, &signalNumber, sizeof(signalNumber)) < 0)
        error("Error sending signal number to server");

    // Receive the signal setup status
    int success;
    if (read(clientSocket, &success, sizeof(success)) < 0)
        error("Error receiving signal setup status from server");

    if (success) {
        printf("Signal envoyé avec succés.\n");

        if (signalNumber == 9) {
            printf("Le serveur est entrain de se terminer...\n");
            close(clientSocket);
            exit(EXIT_SUCCESS);
        }
    } else {
        printf("Failed to set up signal on the server.\n");
    }
}

void printMenu() {
 printf("%s---------------------------- Menu ----------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);
    printf("%s1. Afficher la date et l'heure%s\n", ANSI_COLOR_GREEN, ANSI_COLOR_RESET);
    printf("%s2. Afficher la liste des fichiers%s\n", ANSI_COLOR_GREEN, ANSI_COLOR_RESET);
    printf("%s3. Afficher le contenu d'un fichier%s\n", ANSI_COLOR_GREEN, ANSI_COLOR_RESET);
    printf("%s4. Afficher la durée écoulée%s\n", ANSI_COLOR_GREEN, ANSI_COLOR_RESET);
    printf("%s5. Envoyer un signal au serveur%s\n", ANSI_COLOR_GREEN, ANSI_COLOR_RESET);
    printf("%s6. Calculer le Factoriel d'un entier%s\n", ANSI_COLOR_GREEN, ANSI_COLOR_RESET);
    printf("%s0. Quitter%s\n", ANSI_COLOR_RED, ANSI_COLOR_RESET);
 printf("%s---------------------------------------------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);
    printf("%sEntrez votre choix :\n %s", ANSI_COLOR_YELLOW, ANSI_COLOR_RESET);

}

int main(int argc, char *argv[]) {
 char filename[BUFFER_SIZE];


    if (argc != 3) {
        fprintf(stderr, "Usage: %s <serveur_hostname> <port>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char *serverHostname = argv[1];
    const int serverPort = atoi(argv[2]);

    int clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket < 0)
        error("Erreur lors de la création de la socket");

    struct sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(serverPort);
    if (inet_aton(serverHostname, &serverAddr.sin_addr) == 0)
        error("Erreur lors de la conversion de l'adresse du serveur");

    if (connect(clientSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0)
        error("Erreur lors de la connexion au serveur");

    printf("Connecté au serveur\n");

authenticateUser(clientSocket);
    
    char buffer[BUFFER_SIZE];
  int clientNumber;
    int choice;
   
    while (1) {
        printMenu();
         printf("%s %s > %s",ANSI_COLOR_MAGENTA,name, ANSI_COLOR_RESET);

         scanf("%d", &choice);

        if (write(clientSocket, &choice, sizeof(choice)) < 0)
            error("Erreur lors de l'envoi du choix au serveur");

        if (choice == 0) {
            break;
        }




        switch (choice) {
        case 1:
  printf("%s--------------------------- Choix1 ---------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET); 
        receiveString(clientSocket, buffer, sizeof(buffer));
        printf("%s\n", buffer);
printf("%s---------------------------------------------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);
        break;
    case 2: 
    printf("%s-------------------------- Choix2 ---------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);  
    printf("\n%s✅ Liste des fichiers ✅%s\n",     ANSI_COLOR_GREEN, ANSI_COLOR_RESET);
    while (1) {
        receiveString(clientSocket, buffer, sizeof(buffer));
        if (buffer[0] == '\0') {
            break;  // Fin de la liste des fichiers
        }
        printf("%s\n", buffer);
    }
printf("%s---------------------------------------------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);

    break;

     
           case 3:
    // Le client envoie le nom du fichier au serveur
printf("%s--------------------------- Choix3 ---------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);

// Get the filename
printf("%sVeuillez saisir le nom du fichier : %s", ANSI_COLOR_GREEN, ANSI_COLOR_RESET);
scanf("%s", filename);
sendString(clientSocket, filename);

// Receive and display the content of the file
receiveFileContent(clientSocket, filename);
printf("\n%s✅ Contenu du fichier reçu et affiché avec succès. ✅%s\n", ANSI_COLOR_GREEN, ANSI_COLOR_RESET);

// End of file management section
  printf("%s---------------------------------------------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);

    break;
            case 4: {
                int elapsedTime;
printf("%s--------------------------- Choix4 ---------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);
                if (read(clientSocket, &elapsedTime, sizeof(elapsedTime)) < 0)
                    error("Erreur lors de la lecture de la durée écoulée");
                printf("✅ Durée écoulée depuis le début de la connexion : %d secondes ✅\n", elapsedTime);
printf("%s---------------------------------------------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);
                break;
            }
            case 5:
printf("%s--------------------------- Choix5 ---------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);
                sendSignalToServer(clientSocket);
 printf("%s---------------------------------------------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);
                break;
            case 6:
printf("%s--------------------------- Choix6 ---------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);
printf("%sVeuillez saisir le nombre : %s", ANSI_COLOR_GREEN, ANSI_COLOR_RESET);
    scanf("%d", &clientNumber);
    sendNumber(clientSocket, clientNumber);

    // Receive the result from the server
    unsigned long long factorialResult = receiveResult(clientSocket);

    printf(" ✅ Résultat du factoriel a partir du serveur : %llu ✅\n", factorialResult);
printf("%s---------------------------------------------------------------%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);
                break;
            default:
                printf("Choix non valide ❌\n");
                break;
        }
    }

    printf("Déconnexion...\n");
    close(clientSocket);

    return 0;
}
