#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>

#define NMAX 100

void error(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <serveur_hostname>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char *serveur_hostname = argv[1];

    // Récupérer le numéro de port du serveur
    int serveur_port;
    printf("Veuillez saisir le numéro de port du serveur : ");
    scanf("%d", &serveur_port);

    // Créer une socket UDP
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0)
        error("Erreur lors de la création de la socket");

    // Préparer l'adresse du serveur
    struct sockaddr_in serveur_addr;
    serveur_addr.sin_family = AF_INET;
    serveur_addr.sin_port = htons(serveur_port);
    if (inet_aton(serveur_hostname, &serveur_addr.sin_addr) == 0)
        error("Erreur lors de la conversion de l'adresse du serveur");

    // Initialiser la graine du générateur de nombres aléatoires avec le temps actuel
    srand((unsigned int)time(NULL));

    // Générer un nombre aléatoire n
    int n = rand() % NMAX + 1;

    // Afficher le nombre généré par le client
    printf("Nombre généré par le client : %d\n", n);

    // Envoyer n au serveur
    if (sendto(sockfd, &n, sizeof(n), 0, (struct sockaddr*)&serveur_addr, sizeof(serveur_addr)) < 0)
        error("Erreur lors de l'envoi du nombre au serveur");

    // Afficher la demande et attendre la réponse du serveur
    printf("Demande envoyée au serveur. En attente de la réponse...\n");

    int *reponse = malloc(n * sizeof(int));
    socklen_t addr_len = sizeof(serveur_addr);
    if (recvfrom(sockfd, reponse, n * sizeof(int), 0, (struct sockaddr*)&serveur_addr, &addr_len) < 0)
        error("Erreur lors de la réception de la réponse du serveur");

    // Afficher la réponse
    printf("Réponse du serveur : ");
    for (int i = 0; i < n; ++i) {
        printf("%d", reponse[i]);
        if (i < n - 1) {
            printf(" | ");
        }
    }
    printf("\n");

    // Libérer la mémoire
    free(reponse);

    // Fermer la socket
    close(sockfd);

    return 0;
}
