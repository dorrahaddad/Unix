#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>
#include <dirent.h>
#include <sys/types.h>
#include <signal.h>
#include <stdint.h>

#define BUFFER_SIZE 8192

// ANSI escape codes for text color
#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define ANSI_COLOR_RESET   "\x1b[0m"

void error(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}

void sendString(int sockfd, const char *str) {
    size_t length = strlen(str) + 1;
    if (write(sockfd, &length, sizeof(length)) < 0)
        error("Error sending string length");

    if (write(sockfd, str, length) < 0)
        error("Error sending string");
}

void receiveString(int sockfd, char *buffer, size_t bufferSize) {
    size_t length;
    recv(sockfd, &length, sizeof(length), 0);

    if (length > bufferSize) {
        fprintf(stderr, "Buffer size is not sufficient.\n");
        exit(EXIT_FAILURE);
    }

    ssize_t totalBytesReceived = 0;
    while (totalBytesReceived < length) {
        ssize_t bytesRead = recv(sockfd, buffer + totalBytesReceived, length - totalBytesReceived, 0);
        if (bytesRead <= 0) {
            fprintf(stderr, "Error receiving string.\n");
            exit(EXIT_FAILURE);
        }
        totalBytesReceived += bytesRead;
    }

    buffer[length] = '\0';
}

int authenticateUser(int clientSocket) {
    char username[BUFFER_SIZE];
    char password[BUFFER_SIZE];

    receiveString(clientSocket, username, sizeof(username));
    receiveString(clientSocket, password, sizeof(password));

    if ((strcmp(username, "user1") == 0 && strcmp(password, "pass1") == 0) ||
        (strcmp(username, "user2") == 0 && strcmp(password, "pass2") == 0)) {
        int authResult = 1;
        if (write(clientSocket, &authResult, sizeof(authResult)) < 0)
            error("Error sending authentication result");
        printf("%s✅ Authentification réussie pour l'utilisateur %s ✅%s\n", ANSI_COLOR_GREEN, username, ANSI_COLOR_RESET);
        return 1;
    } else {
        int authResult = 0;
        if (write(clientSocket, &authResult, sizeof(authResult)) < 0)
            error("Error sending authentication result");
        fprintf(stderr, "%s❌ Authentification échouée pour l'utilisateur %s ❌%s\n", ANSI_COLOR_RED, username, ANSI_COLOR_RESET);
        return 0;
    }
}

void sendDateTime(int clientSocket) {
    time_t currentTime;
    struct tm *localTime;

    time(&currentTime);
    localTime = localtime(&currentTime);

    char dateTime[BUFFER_SIZE];
    strftime(dateTime, BUFFER_SIZE, "%A, %B %d %Y %H:%M:%S", localTime);

    size_t dateTimeLen = strlen(dateTime) + 1;
    if (send(clientSocket, &dateTimeLen, sizeof(dateTimeLen), 0) < 0)
        error("Error sending date and time length");

    if (send(clientSocket, dateTime, dateTimeLen, 0) < 0)
        error("Error sending date and time");
}

void sendFileList(int clientSocket, const char *directoryPath) {
    DIR *dir;
    struct dirent *entry;

    dir = opendir(directoryPath);
    if (!dir)
        error("Error opening directory");

    while ((entry = readdir(dir)) != NULL) {
        sendString(clientSocket, entry->d_name);
    }

    sendString(clientSocket, "");

    closedir(dir);
}

void sendFileContent(int clientSocket, const char *filePath) {
    FILE *file = fopen(filePath, "r");
    if (!file)
        error("Error opening file");

    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    rewind(file);

    if (send(clientSocket, &fileSize, sizeof(fileSize), 0) < 0)
        error("Error sending file size");

    char buffer[BUFFER_SIZE];
    size_t bytesRead;

    while ((bytesRead = fread(buffer, 1, sizeof(buffer), file)) > 0) {
        if (send(clientSocket, buffer, bytesRead, 0) < 0)
            error("Error sending file content");
    }

    fclose(file);
}

void receiveFileContent(int sockfd, FILE *file) {
    char buffer[BUFFER_SIZE];
    size_t totalBytesReceived = 0;
    ssize_t bytesRead;

    while ((bytesRead = recv(sockfd, buffer, sizeof(buffer), 0)) > 0) {
        fwrite(buffer, 1, bytesRead, file);
        totalBytesReceived += bytesRead;
    }

    if (bytesRead < 0) {
        perror("Error receiving file content");
        exit(EXIT_FAILURE);
    }
}

void sendElapsedTime(int clientSocket, time_t startTime) {
    time_t currentTime;
    time(&currentTime);

    int elapsedTime = difftime(currentTime, startTime);

    if (write(clientSocket, &elapsedTime, sizeof(elapsedTime)) < 0)
        error("Error sending elapsed time");
}

void handleSignal(int signalNumber) {
    // Handle the signal as needed
    if (signalNumber == 9) {
        printf(" Le client a envoyé le signal %d au serveur : EXIT❌.\n", signalNumber);
        exit(EXIT_SUCCESS);
    }else {
 printf(" Le client a envoyé le signal %d au serveur.\n", signalNumber);
}

}

void handleClientSignal(int clientSocket) {
    int signalNumber;
    if (read(clientSocket, &signalNumber, sizeof(signalNumber)) == 0)
        error("Error reading signal number from client");

    // Install the signal handler
    signal(signalNumber, handleSignal);

   
    handleSignal(signalNumber);
    

    // Notify the client that the signal has been set up
    int success = 1;
    if (write(clientSocket, &success, sizeof(success)) < 0)
        error("Error sending signal setup status to client");
}

unsigned long long calculateFactorial(int n) {
    if (n < 0) {
        // Handling an invalid input (factorial is defined only for n >= 0)
        return -1;  // Arbitrary value to indicate an error
    }

    unsigned long long result = 1;

    for (int i = 1; i <= n; ++i) {
        result *= i;
    }

    return result;
}

void handleClientRequest(int clientSocket) {
    int clientNumber;
    ssize_t bytesRead = recv(clientSocket, &clientNumber, sizeof(clientNumber), 0);

    if (bytesRead <= 0) {
        perror("Error receiving client request");
        return;
    }

    printf("Le Nombre reçu du client est : %d\n", clientNumber);

    // Calculate the factorial
    long factorialResult = calculateFactorial(clientNumber);

    // Send the result back to the client
    if (send(clientSocket, &factorialResult, sizeof(factorialResult), 0) < 0) {
        perror("Error sending factorial result");
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const int port = atoi(argv[1]);

    int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket < 0)
        error("Error creating socket");

    struct sockaddr_in serverAddr, clientAddr;
    socklen_t clientAddrLen = sizeof(clientAddr);

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(port);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(serverSocket, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0)
        error("Error binding socket");

    if (listen(serverSocket, 5) < 0)
        error("Error listening on socket");

    printf("%sServer attend les connexions des clients...%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);

    while (1) {
        int clientSocket = accept(serverSocket, (struct sockaddr *)&clientAddr, &clientAddrLen);
        if (clientSocket < 0)
            error("Error accepting connection");

        printf("%sNouvelle connexion acceptée%s\n", ANSI_COLOR_GREEN, ANSI_COLOR_RESET);

        // Authentication
        if (!authenticateUser(clientSocket)) {
            fprintf(stderr, "%s❌ Authentification échouée. ❌%s\n", ANSI_COLOR_RED, ANSI_COLOR_RESET);
            close(clientSocket);
            continue;
        }

    /*   printf("%s✅ Authentification réussie ✅%s\n", ANSI_COLOR_GREEN, ANSI_COLOR_RESET);*/

        time_t startTime;
        time(&startTime);

        while (1) {
            int choice;
            printf("\n%sEn attente du choix du client...%s\n", ANSI_COLOR_BLUE, ANSI_COLOR_RESET);

            int bytesRead = read(clientSocket, &choice, sizeof(choice));
            if (bytesRead <= 0) {
                if (bytesRead == 0) {
                    printf("\n%sClient closed the connection.%s\n", ANSI_COLOR_YELLOW, ANSI_COLOR_RESET);
                } else {
                    perror("Error reading client's choice");
                }

                break;
            }

            printf("\n%sChoix du client reçu: %d%s\n", ANSI_COLOR_BLUE, choice, ANSI_COLOR_RESET);

            switch (choice) {
                char filename[BUFFER_SIZE];

            case 1:
                sendDateTime(clientSocket);
                break;
            case 2:
                sendFileList(clientSocket, "./");
                break;
            case 3:
                receiveString(clientSocket, filename, sizeof(filename));
                sendFileContent(clientSocket, filename);
                break;
            case 4:
                sendElapsedTime(clientSocket, startTime);
                break;
            case 5:
                handleClientSignal(clientSocket);
                break;
            case 6:
                handleClientRequest(clientSocket);
                break;

            case 0:
                printf("%sClient déconnecté%s\n", ANSI_COLOR_YELLOW, ANSI_COLOR_RESET);
                close(clientSocket);
                break;
            default:
                printf("%sChoix invalide%s\n", ANSI_COLOR_RED, ANSI_COLOR_RESET);
                break;
            }

            if (choice == 0) {
                break;
            }
        }
    }

    close(serverSocket);

    return 0;
}

